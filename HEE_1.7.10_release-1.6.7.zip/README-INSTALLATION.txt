== CLIENT ==
1. Download Forge installer, open it and install
2. Open the Minecraft launcher and select Forge in the profile list
3. Click Edit Profile and Open Game Dir, this opens a folder
4. Create a new folder called mods
5. Download the mod and open it in an archiving software
6. Drag both .jar files (HardcoreEnderExpansion & Java7Checker) into the mods folder
7. Go back to Minecraft launcher and play! :)

== SERVER ==
1. Download Forge installer, open it, select Install server, choose the location and install
2. Create a new folder called mods
3. Download the mod and open it in an archiving software
4. Drag both .jar files (HardcoreEnderExpansion & Java7Checker) into the mods folder
5. Run forge-(...)-universal.jar to start the server!

Download Forge here: http://www.minecraftforge.net/forum/index.php/board,3.0.html